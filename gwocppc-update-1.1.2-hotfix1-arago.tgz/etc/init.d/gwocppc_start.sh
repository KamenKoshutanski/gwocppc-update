#!/bin/sh

### BEGIN INIT INFO
# Provides:          gwocppd
# Required-Start:    secc_start.sh
# Required-Stop:     
# Default-Start:     S
# Default-Stop:
# Short-Description: Start ocppc.
### END INIT INFO

[[ -z "${OCPP_PATH}" ]] && export OCPP_PATH=/home/root/ocpp || export OCPP_PATH=${OCPP_PATH}
NAME=gwocppc
PIDFILE=/var/run/$NAME.pid
PYTHON_FILE="/usr/bin/python3"

MMC_MOUNT_PATH="/mnt/mmcblk"
export OCPP_PATH="/home/root/ocpp"
OCPP_PACKAGE="gwocppc.tgz"
OCPP_FIRMWARE="gwocppc"


OCPP_DB_FILE="gwocpp.db"
OCPP_CONF_FILE="ConfigurationKeys.json"
OCPP_ROOT_CA_CERTIFICATION="ca-certificates.pem"
OCPP_MFR_CERTIFICATION="ma-certificates.pem"

copy_file(){
  if [ -f "$1" ]
  then
    echo "OCPP FOUND '$1'"
    /bin/mv -b $1 $2
    /bin/sync
  fi

  echo "OCPP Check '$1' Done."
}

do_start() {
  echo "UPDATE OCPP FIRMWARE EXIST CHECK"
  /bin/mount /dev/mmcblk0p3 $MMC_MOUNT_PATH/

  if [ -f "$MMC_MOUNT_PATH/$OCPP_PACKAGE" ]
  then
    echo "OCPP PACKAGE FOUND ($OCPP_PACKAGE)"
    /bin/mv $OCPP_PATH $OCPP_PATH.old
    /bin/tar -xzf $MMC_MOUNT_PATH/$OCPP_PACKAGE -C /
    /bin/chmod 755 $OCPP_PATH/$OCPP_FIRMWARE
    /bin/cp $OCPP_PATH.old/conf $OCPP_PATH -a
    /bin/cp $OCPP_PATH.old/db $OCPP_PATH -a
    /bin/cp $OCPP_PATH.old/ConfigurationKeys $OCPP_PATH -a
    /bin/cp $OCPP_PATH.old/cert $OCPP_PATH -a
    # -->
    /usr/sbin/update-rc.d -f gwocppc remove
    /usr/sbin/update-rc.d -f gwocppc_start.sh remove
    /usr/sbin/update-rc.d -f gwocppc_start.sh defaults 99
    # <--
    /bin/rm -rf $MMC_MOUNT_PATH/$OCPP_PACKAGE
    /bin/rm -rf $OCPP_PATH.old
    /bin/sync
    echo "OCPP REBOOT"
    /sbin/reboot
  fi

  echo "OCPP Check '$OCPP_PACKAGE' Done."

  ### USB DOWNLOAD

  ## db file download
  copy_file $MMC_MOUNT_PATH/ocpp/$OCPP_DB_FILE $OCPP_PATH/db/$OCPP_DB_FILE

  ## configuration file download
  copy_file $MMC_MOUNT_PATH/ocpp/$OCPP_CONF_FILE $OCPP_PATH/ConfigurationKeys/$OCPP_CONF_FILE

  ## root ca certification file download
  copy_file $MMC_MOUNT_PATH/ocpp/$OCPP_ROOT_CA_CERTIFICATION $OCPP_PATH/cert/$OCPP_ROOT_CA_CERTIFICATION

  ## mfr certification file download
  copy_file $MMC_MOUNT_PATH/ocpp/$OCPP_MFR_CERTIFICATION $OCPP_PATH/cert/$OCPP_MFR_CERTIFICATION

  /bin/umount $MMC_MOUNT_PATH
  /sbin/modprobe g_mass_storage file=/dev/mmcblk0p3 removable=1 ro=0 stall=1
  
  echo "Starting Network"

  if [ -e $PYTHON_FILE ]; then
    /usr/bin/python3 $OCPP_PATH/conf/network.py
  else
    /usr/bin/python $OCPP_PATH/conf/network.py
  fi
  # stdout is not display
  #start-stop-daemon --start --background --pidfile $PIDFILE --exec $OCPP_PATH/gwocppc --make-pidfile
  cd $OCPP_PATH

  echo "Start $NAME..."
  ./$NAME &
}

do_stop() {
  #start-stop-daemon --stop --pidfile $PIDFILE
  pid=`pidof -x $NAME`
  kill -9 $pid
}

case "$1" in
  start)
    echo "Starting gwocppc"
    do_start
    ;;
  stop)
    echo "Stopping gwocppc"
    do_stop
    ;;
  restart)
    do_stop
    sleep 1
    do_start
    ;;
  status)
    pid=`pidof -x $NAME`
    if [ -n "$pid" ]; then
	  echo "$NAME (pid $pid) is running ..."
    else
	  echo "$NAME is stopped"
    fi
    ;;
  *)
    echo "Usage: $0 {start|stop|status|restart}"
    exit 1
esac
exit 0
