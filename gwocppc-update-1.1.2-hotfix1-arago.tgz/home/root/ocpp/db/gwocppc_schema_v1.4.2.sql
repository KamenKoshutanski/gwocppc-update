CREATE TABLE 'charge_box' (
  'id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,
  'charge_box_id' TEXT NOT NULL UNIQUE DEFAULT 'gridwiz-cp',
  'fw_update_status' INTEGER DEFAULT 5 CHECK(fw_update_status >= 0 AND fw_update_status < 14),
  'fw_location' TEXT,
  'fw_retrieve_date' DATETIME,
  'local_list_version' INTEGER DEFAULT -1 CHECK (local_list_version >= -1),
  'session_count' INTEGER DEFAULT 0,
  'fw_download_mode' INTEGER DEFAULT 0,
  'fw_download_request_id' INTEGER DEFAULT 0
);

CREATE TABLE 'availability' (
  'connector_id' INTEGER NOT NULL PRIMARY KEY UNIQUE DEFAULT 0,
  'charge_box_id' TEXT NOT NULL,
  'availability' INTEGER DEFAULT 1 CHECK(availability == 0 OR availability == 1),
  CONSTRAINT fk_charge_box
  FOREIGN KEY(charge_box_id)
  REFERENCES charge_box(charge_box_id)
  ON UPDATE CASCADE
  ON DELETE CASCADE  
);

CREATE TABLE 'diagnostic' (
  'id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,
  'charge_box_id' TEXT NOT NULL,
  'datetime' DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  'log' TEXT,
  CONSTRAINT fk_charge_box
  FOREIGN KEY(charge_box_id)
  REFERENCES charge_box(charge_box_id)
  ON UPDATE CASCADE
  ON DELETE CASCADE
);

CREATE TABLE 'transaction' (
  'id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,
  'charge_box_id' TEXT NOT NULL,
  'session_id' INTEGER DEFAULT 0,
  'action' TEXT,
  'datetime' DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  'transaction' TEXT,
  CONSTRAINT fk_charge_box
  FOREIGN KEY(charge_box_id)
  REFERENCES charge_box(charge_box_id)
  ON UPDATE CASCADE
  ON DELETE CASCADE
);

CREATE TABLE 'session' (
  'session_id' INTEGER NOT NULL PRIMARY KEY UNIQUE,
  'charge_box_id' TEXT NOT NULL,
  'connector_id' INTEGER NOT NULL,
  'transaction_id' INTEGER,
  'reservation_id' INTEGER,
  'idtag' TEXT,
  'expiry_date' DATETIME,
  'status' INTEGER CHECK(status >= 0 AND status < 5),
  'parent_idtag' TEXT,
  'incomplete_reason' INTEGER DEFAULT 0 CHECK (incomplete_reason >= 0), 
  CONSTRAINT fk_charge_box
  FOREIGN KEY(charge_box_id)
  REFERENCES charge_box(charge_box_id)
  ON UPDATE CASCADE
  ON DELETE CASCADE
);

CREATE TABLE 'reservation' (
  'connector_id' INTEGER NOT NULL PRIMARY KEY UNIQUE,
  'charge_box_id' TEXT NOT NULL,
  'reservation_id' INTEGER NOT NULL,
  'idtag' TEXT NOT NULL,
  'expiry_date' DATETIME NOT NULL,
  'parent_idtag' TEXT,
  CONSTRAINT fk_charge_box
  FOREIGN KEY(charge_box_id)
  REFERENCES charge_box(charge_box_id)
  ON UPDATE CASCADE
  ON DELETE CASCADE
);

CREATE TABLE 'authorize_cache' (
  'id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,
  'charge_box_id' TEXT NOT NULL,
  'idtag' TEXT NOT NULL UNIQUE,
  'status' INTEGER CHECK(status >= 0 AND status < 5),
  'expiry_date' DATETIME,
  'parent_idtag' TEXT,
  CONSTRAINT fk_charge_box
  FOREIGN KEY(charge_box_id)
  REFERENCES charge_box(charge_box_id)
  ON UPDATE CASCADE
  ON DELETE CASCADE
);

CREATE TABLE 'local_list' (
  'id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,
  'charge_box_id' TEXT NOT NULL,
  'idtag' TEXT NOT NULL UNIQUE,
  'expiry_date' DATETIME,
  'parent_idtag' TEXT,
  'status' INTEGER CHECK(status >= 0 AND status < 5),
  CONSTRAINT fk_charge_box
  FOREIGN KEY(charge_box_id)
  REFERENCES charge_box(charge_box_id)
  ON UPDATE CASCADE
  ON DELETE CASCADE
);

CREATE TABLE 'charging_profile' (
  'charging_profile_id' INTEGER NOT NULL PRIMARY KEY UNIQUE,
  'charge_box_id' TEXT NOT NULL,
  'stack_level' INTEGER NOT NULL,
  'charging_profile_purpose' INTEGER CHECK(charging_profile_purpose >= 0 AND charging_profile_purpose < 3),
  'charging_profile_kind' INTEGER CHECK(charging_profile_kind >= 0 AND charging_profile_kind < 3),
  'recurrency_kind_type' INTEGER CHECK(recurrency_kind_type == 0 OR recurrency_kind_type == 1),
  'valid_from' DATETIME,
  'valid_to' DATETIME,
  'duration' INTEGER,
  'start_schedule' DATETIME,
  'scheduling_unit' INTEGER NOT NULL CHECK(scheduling_unit == 0 OR scheduling_unit == 1),
  'min_charging_rate' DECIMAL,
  CONSTRAINT fk_charge_box
  FOREIGN KEY(charge_box_id)
  REFERENCES charge_box(charge_box_id)
  ON UPDATE CASCADE
  ON DELETE CASCADE
);

CREATE TABLE 'charging_schedule_period' (
  'charging_profile_id' INTEGER NOT NULL,
  'period_idx' INTEGER NOT NULL,
  'start_period' INTEGER NOT NULL,
  'limit' INTEGER NOT NULL,
  'phase' INTEGER NOT NULL,
  PRIMARY KEY(charging_profile_id,period_idx),
  CONSTRAINT fk_charging_profile
  FOREIGN KEY(charging_profile_id)
  REFERENCES charging_profile(charging_profile_id)
  ON UPDATE CASCADE
  ON DELETE CASCADE
);

CREATE TABLE 'bind_profile' (
  'connector_id' INTEGER NOT NULL,
  'charging_profile_id' INTEGER NOT NULL,
  PRIMARY KEY(connector_id,charging_profile_id),
  CONSTRAINT fk_charging_profile
  FOREIGN KEY(charging_profile_id)
  REFERENCES charging_profile(charging_profile_id)
  ON UPDATE CASCADE
  ON DELETE NO ACTION
);

CREATE TRIGGER 'charge_box_id_update'
AFTER UPDATE OF 'charge_box_id' ON 'charge_box'
BEGIN
  DELETE FROM 'availability';
  DELETE FROM 'session';
  DELETE FROM 'transaction';
  DELETE FROM 'reservation';
END;
