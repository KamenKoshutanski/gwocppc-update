#!/bin/sh

MMC_MOUNT_PATH="/mnt/mmcblk"

case "$1" in
  ocppc)
    /bin/mount /dev/mmcblk0p3 $MMC_MOUNT_PATH/
    
    if [ -f "$2" ]
    then
      /bin/mv -b $2 $MMC_MOUNT_PATH/gwocppc.tgz
      /bin/sync
      sleep 1
    fi
  ;;
  evse)
  ;;
esac

exit 0
