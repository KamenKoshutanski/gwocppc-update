import json
import os

CURRENT_PATH = os.path.dirname(os.path.abspath(__file__))
JSON_PATH = os.path.join(CURRENT_PATH, "../ConfigurationKeys", "ConfigurationKeys.json")

with open(JSON_PATH) as file:
	data = json.load(file)

	json_kv = data["ConfigurationKey"]

	print("################ NETWORK INFO ################")
	for i in range(len(json_kv)):
		if json_kv[i]["Key"] == "system.network.mode":
			MODE = json_kv[i]["Value"]
			print(" >>MODE: %s" % MODE)
		elif json_kv[i]["Key"] == "system.network.ip":
			IP = json_kv[i]["Value"]
			print(" >>IP: %s" % IP)
		elif json_kv[i]["Key"] == "system.network.netmask":
			NETMASK = json_kv[i]["Value"]
			print(" >>NETMASK: %s" % NETMASK)
		elif json_kv[i]["Key"] == "system.network.gateway":
			GATEWAY = json_kv[i]["Value"]
			print(" >>GATEWAY: %s" % GATEWAY)
		elif json_kv[i]["Key"] == "system.network.dns":
			DNS = json_kv[i]["Value"]
			print(" >>DNS: %s" % DNS)

	print("################################################")

if MODE == "dhcp":
	print("DHCP MODE...")
	os.system('udhcpc -i eth1 &')
else:
	print("STATIC MODE...")
	buffer = "ifconfig eth1 %s netmask %s up" % (IP, NETMASK)
	os.system(buffer)
	buffer = "route add default gw %s" % (GATEWAY)
	os.system(buffer)
	#buffer = "echo nameserver %s > /etc/resolv.conf" % (DNS)
	buffer = 'echo -n "nameserver %s" | resolvconf -a eth1' % (DNS)
	os.system(buffer)


file.close()
